import math

p = int(input("Enter p value"))
q = int(input("Enter q value"))

n = p * q
phi = (p - 1) * (q - 1)
e = 2

while (e < phi):
    if (math.gcd(e, phi) == 1):
        break
    else:
        e = e + 1
print('e', e)

d=1
while((d*e)%phi!=1):
        d+=1
print('d', d)

msg = int(input("Enter message"))
print("Messsage before encryption:", msg)

c = pow(msg, e, n)
print("Encrypted data= ", c)

m = pow(c, d, n)
print("Original Message after decryption=", m)
